import os
import pymysql
import collections

conn = pymysql.connect(
    host = "jmm.cvxf3ahhscl8.us-east-2.rds.amazonaws.com",
    port = 3306,
    user = 'JMM',
    passwd = '1q2w3e4r',
    db = 'JMM',
    charset = 'utf8'
)

cur = conn.cursor()

loc = str(input("지역 입력:"))
type = str(input("음식 종류 입력:"))
store = str(input("맛집 종류 입력:"))

cur.execute("INSERT INTO CHOICE VALUES('%s','%s','%s');" %(loc,type,store))

conn.commit()
conn.close()

